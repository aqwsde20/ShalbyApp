class UserModel {
  final String id;
  final String email;
  final String displayName;
  final DateTime? registrationDate;
  final DateTime? lastLoginDate;
  final int points;
  final bool isVerified;
  final int totalAdViews;
  final String? profilePictureUrl;
  final String? phoneNumber;
  final String? paymentMethod;
  final String? paymentDetails;

  UserModel({
    required this.id,
    required this.email,
    required this.displayName,
    this.registrationDate,
    this.lastLoginDate,
    required this.points,
    required this.isVerified,
    required this.totalAdViews,
    this.profilePictureUrl,
    this.phoneNumber,
    this.paymentMethod,
    this.paymentDetails,
  });

  factory UserModel.fromMap(Map<String, dynamic> map, String id) {
    return UserModel(
      id: id,
      email: map['email'] ?? '',
      displayName: map['displayName'] ?? '',
      registrationDate: map['registrationDate'] != null
          ? (map['registrationDate'] as dynamic).toDate()
          : null,
      lastLoginDate: map['lastLoginDate'] != null
          ? (map['lastLoginDate'] as dynamic).toDate()
          : null,
      points: map['points'] ?? 0,
      isVerified: map['isVerified'] ?? false,
      totalAdViews: map['totalAdViews'] ?? 0,
      profilePictureUrl: map['profilePictureUrl'],
      phoneNumber: map['phoneNumber'],
      paymentMethod: map['paymentMethod'],
      paymentDetails: map['paymentDetails'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'email': email,
      'displayName': displayName,
      'registrationDate': registrationDate,
      'lastLoginDate': lastLoginDate,
      'points': points,
      'isVerified': isVerified,
      'totalAdViews': totalAdViews,
      'profilePictureUrl': profilePictureUrl,
      'phoneNumber': phoneNumber,
      'paymentMethod': paymentMethod,
      'paymentDetails': paymentDetails,
    };
  }

  UserModel copyWith({
    String? id,
    String? email,
    String? displayName,
    DateTime? registrationDate,
    DateTime? lastLoginDate,
    int? points,
    bool? isVerified,
    int? totalAdViews,
    String? profilePictureUrl,
    String? phoneNumber,
    String? paymentMethod,
    String? paymentDetails,
  }) {
    return UserModel(
      id: id ?? this.id,
      email: email ?? this.email,
      displayName: displayName ?? this.displayName,
      registrationDate: registrationDate ?? this.registrationDate,
      lastLoginDate: lastLoginDate ?? this.lastLoginDate,
      points: points ?? this.points,
      isVerified: isVerified ?? this.isVerified,
      totalAdViews: totalAdViews ?? this.totalAdViews,
      profilePictureUrl: profilePictureUrl ?? this.profilePictureUrl,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      paymentDetails: paymentDetails ?? this.paymentDetails,
    );
  }
}
