class AdViewLog {
  final String userId;
  final String adType;
  final DateTime viewTime;
  final int points;
  final String? deviceId;
  final String? ipAddress;

  AdViewLog({
    required this.userId,
    required this.adType,
    required this.viewTime,
    required this.points,
    this.deviceId,
    this.ipAddress,
  });

  factory AdViewLog.fromMap(Map<String, dynamic> map, String id) {
    return AdViewLog(
      userId: map['userId'] ?? '',
      adType: map['adType'] ?? '',
      viewTime: map['viewTime'] != null
          ? (map['viewTime'] as dynamic).toDate()
          : DateTime.now(),
      points: map['points'] ?? 0,
      deviceId: map['deviceId'],
      ipAddress: map['ipAddress'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'adType': adType,
      'viewTime': viewTime,
      'points': points,
      'deviceId': deviceId,
      'ipAddress': ipAddress,
    };
  }
}
