import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions غير مدعوم لهذا النظام.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyBf-dWoXzFSN3NOTLEda_7G2rJGPG0oW8w',
    appId: '1:536082129735:web:242ab39ab918720f426262',
    messagingSenderId: '536082129735',
    projectId: 'shalby-ads-a3961',
    authDomain: 'shalby-ads-a3961.firebaseapp.com',
    storageBucket: 'shalby-ads-a3961.firebasestorage.app',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyBf-dWoXzFSN3NOTLEda_7G2rJGPG0oW8w',
    appId: '1:536082129735:android:242ab39ab918720f426262',
    messagingSenderId: '536082129735',
    projectId: 'shalby-ads-a3961',
    storageBucket: 'shalby-ads-a3961.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyBf-dWoXzFSN3NOTLEda_7G2rJGPG0oW8w',
    appId: '1:536082129735:ios:242ab39ab918720f426262',
    messagingSenderId: '536082129735',
    projectId: 'shalby-ads-a3961',
    storageBucket: 'shalby-ads-a3961.firebasestorage.app',
    iosClientId: '1:536082129735:ios:242ab39ab918720f426262',
    iosBundleId: 'com.shalby',
  );
}
