class AppConstants {
  // Firebase Collections
  static const String usersCollection = 'users';
  static const String adViewsCollection = 'adViews';
  static const String withdrawalRequestsCollection = 'withdrawalRequests';
  static const String identityVerificationsCollection = 'identityVerifications';
  static const String adminsCollection = 'admins';
  
  // Storage Paths
  static const String profilePicturesPath = 'profilePictures';
  static const String identityVerificationsPath = 'identityVerifications';
  
  // Ad Constants
  static const int maxDailyAds = 50;
  static const int pointsPerAd = 10;
  static const int minWithdrawalPoints = 1000;
  static const int minDaysBeforeWithdrawal = 7;
  
  // Verification Constants
  static const int maxVerificationAttempts = 3;
  static const int verificationExpiryDays = 30;
  
  // Shared Preferences Keys
  static const String tokenKey = 'auth_token';
  static const String userIdKey = 'user_id';
  static const String dailyAdsCountKey = 'daily_ads_count';
  static const String lastAdViewTimeKey = 'last_ad_view_time';
  
  // Error Messages
  static const String networkErrorMessage = 'تعذر الاتصال بالإنترنت. يرجى التحقق من اتصالك والمحاولة مرة أخرى.';
  static const String serverErrorMessage = 'حدث خطأ في الخادم. يرجى المحاولة مرة أخرى لاحقاً.';
  static const String authErrorMessage = 'فشل في المصادقة. يرجى التحقق من بيانات الاعتماد الخاصة بك.';
  static const String adLoadErrorMessage = 'فشل في تحميل الإعلان. يرجى المحاولة مرة أخرى.';
  
  // Success Messages
  static const String loginSuccessMessage = 'تم تسجيل الدخول بنجاح!';
  static const String registerSuccessMessage = 'تم إنشاء الحساب بنجاح!';
  static const String adViewSuccessMessage = 'تمت إضافة النقاط بنجاح!';
  static const String withdrawalRequestSuccessMessage = 'تم إرسال طلب السحب بنجاح!';
  static const String verificationSuccessMessage = 'تم إرسال طلب التحقق بنجاح!';
}
