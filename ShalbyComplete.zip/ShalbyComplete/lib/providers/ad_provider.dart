import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:unity_ads_plugin/unity_ads_plugin.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shalby/models/ad_view_log.dart';
import 'package:shalby/utils/constants.dart';

class AdProvider with ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  
  bool _isLoading = false;
  String _errorMessage = '';
  int _dailyAdCount = 0;
  DateTime? _lastAdViewTime;
  BannerAd? _bannerAd;
  InterstitialAd? _interstitialAd;
  RewardedAd? _rewardedAd;
  
  bool get isLoading => _isLoading;
  String get errorMessage => _errorMessage;
  int get dailyAdCount => _dailyAdCount;
  DateTime? get lastAdViewTime => _lastAdViewTime;
  BannerAd? get bannerAd => _bannerAd;
  bool get isBannerAdLoaded => _bannerAd != null;
  bool get isInterstitialAdLoaded => _interstitialAd != null;
  bool get isRewardedAdLoaded => _rewardedAd != null;
  
  AdProvider() {
    _initializeAds();
    _loadAdCounts();
  }
  
  Future<void> _initializeAds() async {
    await MobileAds.instance.initialize();
    
    // تهيئة Unity Ads
    if (!kIsWeb) {
      await UnityAds.init(
        gameId: Platform.isAndroid 
            ? 'YOUR_ANDROID_GAME_ID' 
            : 'YOUR_IOS_GAME_ID',
        testMode: true,
        onComplete: () => print('Unity Ads تم التهيئة بنجاح'),
        onFailed: (error, message) => print('فشل تهيئة Unity Ads: $message'),
      );
    }
    
    _loadBannerAd();
    _loadInterstitialAd();
    _loadRewardedAd();
  }
  
  Future<void> _loadAdCounts() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _dailyAdCount = prefs.getInt(AppConstants.dailyAdsCountKey) ?? 0;
      
      final lastAdTimeString = prefs.getString(AppConstants.lastAdViewTimeKey);
      if (lastAdTimeString != null) {
        _lastAdViewTime = DateTime.parse(lastAdTimeString);
        
        // إعادة تعيين العداد اليومي إذا كان اليوم مختلفًا
        final now = DateTime.now();
        if (_lastAdViewTime!.day != now.day || 
            _lastAdViewTime!.month != now.month || 
            _lastAdViewTime!.year != now.year) {
          _dailyAdCount = 0;
          await prefs.setInt(AppConstants.dailyAdsCountKey, 0);
        }
      }
      
      notifyListeners();
    } catch (e) {
      print('خطأ في تحميل عدد الإعلانات: $e');
    }
  }
  
  void _loadBannerAd() {
    _bannerAd = BannerAd(
      adUnitId: 'ca-app-pub-3940256099942544/6300978111', // معرف إعلان تجريبي
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) {
          notifyListeners();
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          _bannerAd = null;
          notifyListeners();
          print('فشل تحميل إعلان البانر: ${error.message}');
        },
      ),
    );
    
    _bannerAd!.load();
  }
  
  void _loadInterstitialAd() {
    InterstitialAd.load(
      adUnitId: 'ca-app-pub-3940256099942544/1033173712', // معرف إعلان تجريبي
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _interstitialAd = ad;
          notifyListeners();
        },
        onAdFailedToLoad: (error) {
          print('فشل تحميل الإعلان البيني: ${error.message}');
        },
      ),
    );
  }
  
  void _loadRewardedAd() {
    RewardedAd.load(
      adUnitId: 'ca-app-pub-3940256099942544/5224354917', // معرف إعلان تجريبي
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _rewardedAd = ad;
          notifyListeners();
        },
        onAdFailedToLoad: (error) {
          print('فشل تحميل إعلان المكافأة: ${error.message}');
        },
      ),
    );
  }
  
  Future<bool> showInterstitialAd() async {
    if (_interstitialAd == null) {
      _errorMessage = AppConstants.adLoadErrorMessage;
      notifyListeners();
      return false;
    }
    
    bool adShown = false;
    
    _interstitialAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _interstitialAd = null;
        _loadInterstitialAd();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        ad.dispose();
        _interstitialAd = null;
        _loadInterstitialAd();
        _errorMessage = 'فشل عرض الإعلان: ${error.message}';
        notifyListeners();
      },
    );
    
    await _interstitialAd!.show();
    adShown = true;
    
    if (adShown) {
      await _recordAdView('interstitial');
    }
    
    return adShown;
  }
  
  Future<bool> showRewardedAd() async {
    if (_rewardedAd == null) {
      _errorMessage = AppConstants.adLoadErrorMessage;
      notifyListeners();
      return false;
    }
    
    if (_dailyAdCount >= AppConstants.maxDailyAds) {
      _errorMessage = 'لقد وصلت إلى الحد الأقصى للإعلانات اليومية.';
      notifyListeners();
      return false;
    }
    
    bool adShown = false;
    
    _rewardedAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _rewardedAd = null;
        _loadRewardedAd();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        ad.dispose();
        _rewardedAd = null;
        _loadRewardedAd();
        _errorMessage = 'فشل عرض إعلان المكافأة: ${error.message}';
        notifyListeners();
      },
    );
    
    await _rewardedAd!.show(
      onUserEarnedReward: (_, reward) async {
        await _recordAdView('rewarded');
      },
    );
    adShown = true;
    
    return adShown;
  }
  
  Future<bool> showUnityAd() async {
    if (kIsWeb) {
      _errorMessage = 'إعلانات Unity غير مدعومة على الويب.';
      notifyListeners();
      return false;
    }
    
    if (_dailyAdCount >= AppConstants.maxDailyAds) {
      _errorMessage = 'لقد وصلت إلى الحد الأقصى للإعلانات اليومية.';
      notifyListeners();
      return false;
    }
    
    bool adShown = false;
    
    try {
      UnityAds.showVideoAd(
        placementId: 'rewardedVideo',
        onStart: (placementId) => print('بدأ الإعلان: $placementId'),
        onSkipped: (placementId) => print('تم تخطي الإعلان: $placementId'),
        onComplete: (placementId) async {
          print('اكتمل الإعلان: $placementId');
          await _recordAdView('unity');
          adShown = true;
        },
        onFailed: (placementId, error, message) {
          print('فشل الإعلان: $placementId, $message');
          _errorMessage = 'فشل عرض إعلان Unity: $message';
          notifyListeners();
        },
      );
      
      return adShown;
    } catch (e) {
      _errorMessage = 'حدث خطأ أثناء عرض إعلان Unity: $e';
      notifyListeners();
      return false;
    }
  }
  
  Future<void> _recordAdView(String adType) async {
    _isLoading = true;
    notifyListeners();
    
    try {
      final user = _auth.currentUser;
      if (user == null) {
        _errorMessage = 'المستخدم غير مسجل الدخول.';
        _isLoading = false;
        notifyListeners();
        return;
      }
      
      // تحديث عدد الإعلانات اليومي
      _dailyAdCount++;
      _lastAdViewTime = DateTime.now();
      
      // حفظ في التخزين المحلي
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(AppConstants.dailyAdsCountKey, _dailyAdCount);
      await prefs.setString(AppConstants.lastAdViewTimeKey, _lastAdViewTime!.toIso8601String());
      
      // إنشاء سجل مشاهدة الإعلان
      final adViewLog = AdViewLog(
        userId: user.uid,
        adType: adType,
        viewTime: _lastAdViewTime!,
        points: AppConstants.pointsPerAd,
      );
      
      // حفظ في Firestore
      await _firestore.collection(AppConstants.adViewsCollection).add(adViewLog.toMap());
      
      // تحديث نقاط المستخدم
      await _firestore.collection(AppConstants.usersCollection).doc(user.uid).update({
        'points': FieldValue.increment(AppConstants.pointsPerAd),
        'totalAdViews': FieldValue.increment(1),
      });
      
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _errorMessage = 'حدث خطأ أثناء تسجيل مشاهدة الإعلان: $e';
      _isLoading = false;
      notifyListeners();
    }
  }
  
  void disposeBannerAd() {
    _bannerAd?.dispose();
    _bannerAd = null;
  }
  
  void disposeInterstitialAd() {
    _interstitialAd?.dispose();
    _interstitialAd = null;
  }
  
  void disposeRewardedAd() {
    _rewardedAd?.dispose();
    _rewardedAd = null;
  }
  
  void clearError() {
    _errorMessage = '';
    notifyListeners();
  }
  
  @override
  void dispose() {
    disposeBannerAd();
    disposeInterstitialAd();
    disposeRewardedAd();
    super.dispose();
  }
}
