import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:shalby/models/user_model.dart';
import 'package:shalby/utils/constants.dart';

class AuthProvider with ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  
  User? _user;
  UserModel? _userModel;
  bool _isLoading = false;
  String _errorMessage = '';
  
  User? get user => _user;
  UserModel? get userModel => _userModel;
  bool get isLoading => _isLoading;
  bool get isAuthenticated => _user != null;
  String get errorMessage => _errorMessage;
  
  AuthProvider() {
    _initializeUser();
  }
  
  Future<void> _initializeUser() async {
    _user = _auth.currentUser;
    if (_user != null) {
      await _fetchUserData();
    }
    notifyListeners();
  }
  
  Future<void> _fetchUserData() async {
    try {
      final doc = await _firestore.collection(AppConstants.usersCollection).doc(_user!.uid).get();
      if (doc.exists) {
        _userModel = UserModel.fromMap(doc.data()!, doc.id);
      }
    } catch (e) {
      print('خطأ في جلب بيانات المستخدم: $e');
    }
  }
  
  Future<bool> login(String email, String password) async {
    _isLoading = true;
    _errorMessage = '';
    notifyListeners();
    
    try {
      final userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      
      _user = userCredential.user;
      
      if (_user != null) {
        await _fetchUserData();
        
        // تحديث تاريخ آخر تسجيل دخول
        await _firestore.collection(AppConstants.usersCollection).doc(_user!.uid).update({
          'lastLoginDate': FieldValue.serverTimestamp(),
        });
        
        _isLoading = false;
        notifyListeners();
        return true;
      }
      
      _isLoading = false;
      notifyListeners();
      return false;
    } on FirebaseAuthException catch (e) {
      _isLoading = false;
      
      switch (e.code) {
        case 'user-not-found':
          _errorMessage = 'لم يتم العثور على مستخدم بهذا البريد الإلكتروني.';
          break;
        case 'wrong-password':
          _errorMessage = 'كلمة المرور غير صحيحة.';
          break;
        case 'invalid-email':
          _errorMessage = 'البريد الإلكتروني غير صالح.';
          break;
        case 'user-disabled':
          _errorMessage = 'تم تعطيل هذا الحساب.';
          break;
        default:
          _errorMessage = 'حدث خطأ أثناء تسجيل الدخول: ${e.message}';
      }
      
      notifyListeners();
      return false;
    } catch (e) {
      _isLoading = false;
      _errorMessage = 'حدث خطأ غير متوقع: $e';
      notifyListeners();
      return false;
    }
  }
  
  Future<bool> register(String email, String password, String displayName) async {
    _isLoading = true;
    _errorMessage = '';
    notifyListeners();
    
    try {
      final userCredential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      
      _user = userCredential.user;
      
      if (_user != null) {
        // تحديث اسم العرض
        await _user!.updateDisplayName(displayName);
        
        // إنشاء وثيقة المستخدم في Firestore
        final userData = {
          'email': email,
          'displayName': displayName,
          'registrationDate': FieldValue.serverTimestamp(),
          'lastLoginDate': FieldValue.serverTimestamp(),
          'points': 0,
          'isVerified': false,
          'totalAdViews': 0,
        };
        
        await _firestore.collection(AppConstants.usersCollection).doc(_user!.uid).set(userData);
        
        // جلب بيانات المستخدم
        await _fetchUserData();
        
        _isLoading = false;
        notifyListeners();
        return true;
      }
      
      _isLoading = false;
      notifyListeners();
      return false;
    } on FirebaseAuthException catch (e) {
      _isLoading = false;
      
      switch (e.code) {
        case 'email-already-in-use':
          _errorMessage = 'البريد الإلكتروني مستخدم بالفعل.';
          break;
        case 'invalid-email':
          _errorMessage = 'البريد الإلكتروني غير صالح.';
          break;
        case 'weak-password':
          _errorMessage = 'كلمة المرور ضعيفة جدًا.';
          break;
        case 'operation-not-allowed':
          _errorMessage = 'تسجيل الحساب بالبريد الإلكتروني وكلمة المرور غير مفعل.';
          break;
        default:
          _errorMessage = 'حدث خطأ أثناء إنشاء الحساب: ${e.message}';
      }
      
      notifyListeners();
      return false;
    } catch (e) {
      _isLoading = false;
      _errorMessage = 'حدث خطأ غير متوقع: $e';
      notifyListeners();
      return false;
    }
  }
  
  Future<void> logout() async {
    try {
      await _auth.signOut();
      _user = null;
      _userModel = null;
      notifyListeners();
    } catch (e) {
      _errorMessage = 'حدث خطأ أثناء تسجيل الخروج: $e';
      notifyListeners();
    }
  }
  
  Future<bool> resetPassword(String email) async {
    _isLoading = true;
    _errorMessage = '';
    notifyListeners();
    
    try {
      await _auth.sendPasswordResetEmail(email: email);
      _isLoading = false;
      notifyListeners();
      return true;
    } on FirebaseAuthException catch (e) {
      _isLoading = false;
      
      switch (e.code) {
        case 'invalid-email':
          _errorMessage = 'البريد الإلكتروني غير صالح.';
          break;
        case 'user-not-found':
          _errorMessage = 'لم يتم العثور على مستخدم بهذا البريد الإلكتروني.';
          break;
        default:
          _errorMessage = 'حدث خطأ أثناء إرسال رابط إعادة تعيين كلمة المرور: ${e.message}';
      }
      
      notifyListeners();
      return false;
    } catch (e) {
      _isLoading = false;
      _errorMessage = 'حدث خطأ غير متوقع: $e';
      notifyListeners();
      return false;
    }
  }
  
  Future<bool> updateProfile(String displayName) async {
    _isLoading = true;
    _errorMessage = '';
    notifyListeners();
    
    try {
      if (_user != null) {
        await _user!.updateDisplayName(displayName);
        
        await _firestore.collection(AppConstants.usersCollection).doc(_user!.uid).update({
          'displayName': displayName,
        });
        
        await _fetchUserData();
        
        _isLoading = false;
        notifyListeners();
        return true;
      }
      
      _isLoading = false;
      _errorMessage = 'المستخدم غير مسجل الدخول.';
      notifyListeners();
      return false;
    } catch (e) {
      _isLoading = false;
      _errorMessage = 'حدث خطأ أثناء تحديث الملف الشخصي: $e';
      notifyListeners();
      return false;
    }
  }
  
  void clearError() {
    _errorMessage = '';
    notifyListeners();
  }
}
