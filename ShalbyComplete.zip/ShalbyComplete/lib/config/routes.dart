import 'package:flutter/material.dart';
import 'package:shalby/screens/login_screen.dart';
import 'package:shalby/screens/register_screen.dart';
import 'package:shalby/screens/home_screen.dart';
import 'package:shalby/screens/profile_screen.dart';
import 'package:shalby/screens/ads_screen.dart';
import 'package:shalby/screens/withdrawal_screen.dart';
import 'package:shalby/screens/points_history_screen.dart';
import 'package:shalby/screens/identity_verification_screen.dart';
import 'package:shalby/screens/admin_dashboard.dart';

class AppRoutes {
  static const String login = '/login';
  static const String register = '/register';
  static const String home = '/home';
  static const String profile = '/profile';
  static const String ads = '/ads';
  static const String withdrawal = '/withdrawal';
  static const String pointsHistory = '/points_history';
  static const String identityVerification = '/identity_verification';
  static const String adminDashboard = '/admin_dashboard';

  static Map<String, WidgetBuilder> get routes {
    return {
      login: (context) => const LoginScreen(),
      register: (context) => const RegisterScreen(),
      home: (context) => const HomeScreen(),
      profile: (context) => const ProfileScreen(),
      ads: (context) => const AdsScreen(),
      withdrawal: (context) => const WithdrawalScreen(),
      pointsHistory: (context) => const PointsHistoryScreen(),
      identityVerification: (context) => const IdentityVerificationScreen(),
      adminDashboard: (context) => const AdminDashboard(),
    };
  }
}
